<?php
// Check if the MySQLi extension is enabled
if (extension_loaded('mysqli')) {
    echo "MySQLi extension is installed and enabled.";
} else {
    echo "MySQLi extension is not enabled.";
}

