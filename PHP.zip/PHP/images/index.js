import load from "./load.gif";
import firstOrgan from "./Viscount.jpg";
import secondOrgan from "./pipeorgan2.jpg";
import pedal from "./pedal.jpg";

const ImageCollection = {
  load,
  firstOrgan,
  secondOrgan,
  pedal,
};

export { ImageCollection };
